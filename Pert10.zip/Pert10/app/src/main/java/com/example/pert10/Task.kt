package com.example.pert10

data class Task(
    val name: String
)
