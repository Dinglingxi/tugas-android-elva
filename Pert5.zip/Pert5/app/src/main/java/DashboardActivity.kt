package com.example.pert5

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    private var nama: String = ""
    private var tugas: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        nama = intent.getStringExtra(MainActivity.EXTRA_NAMA) ?: ""
        tugas = intent.getStringExtra(MainActivity.EXTRA_TUGAS) ?: ""

        val btnTask = findViewById<Button>(R.id.btnTask)
        val btnProfile = findViewById<Button>(R.id.btnProfile)

        // Default fragment: TaskFragment
        if (savedInstanceState == null) {
            openTaskFragment()
        }

        btnTask.setOnClickListener { openTaskFragment() }
        btnProfile.setOnClickListener { openProfileFragment() }
    }

    private fun openTaskFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, TaskFragment.newInstance(nama, tugas))
            .commit()
    }

    private fun openProfileFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, ProfileFragment.newInstance(nama))
            .commit()
    }
}
