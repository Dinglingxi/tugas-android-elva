package com.example.pert5

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class TaskFragment : Fragment() {

    private var nama: String? = null
    private var tugas: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            nama = it.getString(ARG_NAMA)
            tugas = it.getString(ARG_TUGAS)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_task, container, false)

        val tvGreeting = view.findViewById<TextView>(R.id.tvGreeting)
        val tvTask = view.findViewById<TextView>(R.id.tvTask)

        tvGreeting.text = "Halo, $nama 👋"
        tvTask.text = "Tugas hari ini: $tugas"

        return view
    }

    companion object {
        private const val ARG_NAMA = "ARG_NAMA"
        private const val ARG_TUGAS = "ARG_TUGAS"

        fun newInstance(nama: String, tugas: String): TaskFragment {
            val fragment = TaskFragment()
            fragment.arguments = Bundle().apply {
                putString(ARG_NAMA, nama)
                putString(ARG_TUGAS, tugas)
            }
            return fragment
        }
    }
}
