package com.example.pert5

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NAMA = "EXTRA_NAMA"
        const val EXTRA_TUGAS = "EXTRA_TUGAS"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNama = findViewById<EditText>(R.id.etNama)
        val etTugas = findViewById<EditText>(R.id.etTugas)
        val btnLanjut = findViewById<Button>(R.id.btnLanjut)

        btnLanjut.setOnClickListener {
            val nama = etNama.text.toString().trim()
            val tugas = etTugas.text.toString().trim()

            if (nama.isEmpty() || tugas.isEmpty()) {
                Toast.makeText(this, "Nama dan Tugas wajib diisi!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val intent = Intent(this, DashboardActivity::class.java)
            intent.putExtra(EXTRA_NAMA, nama)
            intent.putExtra(EXTRA_TUGAS, tugas)
            startActivity(intent)
        }
    }
}
