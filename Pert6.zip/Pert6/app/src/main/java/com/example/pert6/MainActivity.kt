package com.example.pert6

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnMulai = findViewById<Button>(R.id.btnMulai)
        val btnSelesai = findViewById<Button>(R.id.btnSelesai)

        btnMulai.setOnClickListener {
            tvStatus.text = "Aktivitas Sedang Berlangsung"
            tvStatus.setTextColor(Color.parseColor("#16A34A")) // hijau
        }

        btnSelesai.setOnClickListener {
            tvStatus.text = "Aktivitas Telah Selesai"
            tvStatus.setTextColor(Color.parseColor("#DC2626")) // merah
        }
    }
}