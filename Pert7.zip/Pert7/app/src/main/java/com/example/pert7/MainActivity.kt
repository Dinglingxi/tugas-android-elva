package com.example.pert7

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val btnHapus = findViewById<Button>(R.id.btnHapus)

        val sharedPref = getSharedPreferences("status_pref", Context.MODE_PRIVATE)

        // Ambil data saat aplikasi dibuka
        val statusTersimpan = sharedPref.getString("status", null)
        if (statusTersimpan != null) {
            tvStatus.text = statusTersimpan
        }

        btnSimpan.setOnClickListener {
            val editor = sharedPref.edit()
            editor.putString("status", "Pengguna Sedang Aktif")
            editor.apply()
            tvStatus.text = "Pengguna Sedang Aktif"
        }

        btnHapus.setOnClickListener {
            val editor = sharedPref.edit()
            editor.clear()
            editor.apply()
            tvStatus.text = "Status Dihapus"
        }
    }
}