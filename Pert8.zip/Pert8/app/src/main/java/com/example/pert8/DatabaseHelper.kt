package com.example.pert8

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "catatan.db"
        const val DATABASE_VERSION = 1
        const val TABLE_NAME = "catatan"
        const val COL_ID = "id"
        const val COL_TEXT = "isi"
    }

    // Dipanggil pertama kali database dibuat
    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TEXT TEXT
            )
        """
        db.execSQL(createTable)
    }

    // Dipanggil saat versi database berubah
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // Fungsi simpan data
    fun insertCatatan(text: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COL_TEXT, text)
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    // Fungsi ambil data terakhir
    fun getLastCatatan(): String? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COL_TEXT FROM $TABLE_NAME ORDER BY $COL_ID DESC LIMIT 1",
            null
        )
        var hasil: String? = null
        if (cursor.moveToFirst()) {
            hasil = cursor.getString(0)
        }
        cursor.close()
        db.close()
        return hasil
    }
}