package com.example.pert8

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etCatatan = findViewById<EditText>(R.id.etCatatan)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val tvHasil = findViewById<TextView>(R.id.tvHasil)

        val dbHelper = DatabaseHelper(this)

        val catatanTerakhir = dbHelper.getLastCatatan()
        if (catatanTerakhir != null) {
            tvHasil.text = catatanTerakhir
        }

        btnSimpan.setOnClickListener {
            val text = etCatatan.text.toString()
            if (text.isNotEmpty()) {
                dbHelper.insertCatatan(text)
                tvHasil.text = text
                etCatatan.text.clear()
            }
        }
    }
}