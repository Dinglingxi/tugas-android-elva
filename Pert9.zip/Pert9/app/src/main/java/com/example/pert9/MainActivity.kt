package com.example.pert9

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvQuote = findViewById<TextView>(R.id.tvQuote)
        val btnLoad = findViewById<Button>(R.id.btnLoad)

        btnLoad.setOnClickListener {
            ambilQuote(tvQuote)
        }
    }

    private fun ambilQuote(tv: TextView) {
        thread {
            try {
                val url = URL("https://api.quotable.io/random")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 5000
                conn.readTimeout = 5000

                val response = conn.inputStream.bufferedReader().readText()
                val json = JSONObject(response)
                val quote = json.getString("content")
                val author = json.getString("author")

                runOnUiThread {
                    tv.text = "\"$quote\"\n\n— $author"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tv.text = "Gagal mengambil data"
                }
            }
        }
    }
}