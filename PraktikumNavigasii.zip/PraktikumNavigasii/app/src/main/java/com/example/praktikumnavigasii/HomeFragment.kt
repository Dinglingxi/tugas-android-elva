package com.example.praktikumnavigasii
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate layout fragment_home
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 1. Cari TextView berdasarkan ID yang baru kita buat
        val tvWelcome = view.findViewById<TextView>(R.id.tv_home_welcome)

        // 2. Ambil data 'EXTRA_NAME' dari Activity Induk (Host)
        // Kita gunakan requireActivity().intent karena datanya ada di Intent Activity
        val name = requireActivity().intent.getStringExtra("EXTRA_NAME")

        // 3. Jika datanya ada, ubah tulisan TextView-nya
        if (name != null) {
            tvWelcome.text = "Selamat Datang, $name!"
        }
    }
}