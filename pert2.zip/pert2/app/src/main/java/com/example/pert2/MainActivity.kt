package com.example.pert2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etAngka1: EditText
    private lateinit var etAngka2: EditText
    private lateinit var tvHasil: TextView
    private lateinit var btnTambah: Button
    private lateinit var btnKurang: Button
    private lateinit var btnKali: Button
    private lateinit var btnBagi: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etAngka1 = findViewById(R.id.et_angka1)
        etAngka2 = findViewById(R.id.et_angka2)
        tvHasil = findViewById(R.id.tv_hasil)
        btnTambah = findViewById(R.id.btn_tambah)
        btnKurang = findViewById(R.id.btn_kurang)
        btnKali = findViewById(R.id.btn_kali)
        btnBagi = findViewById(R.id.btn_bagi)

        btnTambah.setOnClickListener { hitung('+') }
        btnKurang.setOnClickListener { hitung('-') }
        btnKali.setOnClickListener { hitung('*') }
        btnBagi.setOnClickListener { hitung('/') }
    }

    private fun hitung(operator: Char) {
        val input1 = etAngka1.text.toString()
        val input2 = etAngka2.text.toString()

        if (input1.isEmpty() || input2.isEmpty()) {
            Toast.makeText(this, "Mohon isi kedua angka!", Toast.LENGTH_SHORT).show()
            return
        }

        val angka1 = input1.toDouble()
        val angka2 = input2.toDouble()

        val hasil = when (operator) {
            '+' -> angka1 + angka2
            '-' -> angka1 - angka2
            '*' -> angka1 * angka2
            '/' -> {
                if (angka2 == 0.0) {
                    Toast.makeText(this, "Tidak bisa dibagi dengan 0!", Toast.LENGTH_SHORT).show()
                    return
                } else {
                    angka1 / angka2
                }
            }
            else -> 0.0
        }

        tvHasil.text = "Hasil: $hasil"
    }
}