package com.example.pert4

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etNama: EditText
    private lateinit var btnSimpan: Button
    private lateinit var tvHasil: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Menghubungkan widget dengan ID
        etNama = findViewById(R.id.et_nama)
        btnSimpan = findViewById(R.id.btn_simpan)
        tvHasil = findViewById(R.id.tv_hasil)

        // Event Button
        btnSimpan.setOnClickListener {
            val nama = etNama.text.toString()

            if (nama.isEmpty()) {
                Toast.makeText(this, "Nama tidak boleh kosong!", Toast.LENGTH_SHORT).show()
            } else {
                tvHasil.text = "Nama tersimpan: $nama"
            }
        }
    }
}