package com.example.elva_app

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.elva_app.adapter.DosenAdapter
import com.example.elva_app.databinding.FragmentDosenBinding
import com.example.elva_app.model.Dosen
import com.example.elva_app.model.DosenResponse
import com.example.elva_app.network.RetrofitClient
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DosenFragment : Fragment(), DosenAdapter.OnDosenActionListener {

    private var _binding: FragmentDosenBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: DosenAdapter
    private var dosenCount = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDosenBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 🚀 Start entrance animations
        startEntranceAnimations()

        // 📝 Setup Spinner with custom style
        setupSpinner()

        // 📋 Setup RecyclerView
        setupRecyclerView()

        // 📊 Fetch initial data
        fetchDosen()

        // 💾 Save button
        binding.btnSimpanDosen.setOnClickListener {
            animateButtonPress(it)
            validateAndSave()
        }
    }

    private fun startEntranceAnimations() {
        // Animate header card
        binding.cardForm.alpha = 0f
        binding.cardForm.translationY = -30f
        binding.cardForm.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .start()
    }

    private fun setupSpinner() {
        val jabatans = arrayOf("Lektor", "Asisten Ahli", "Lektor Kepala", "Profesor")
        val spinnerAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            jabatans
        )
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spJabatan.adapter = spinnerAdapter
    }

    private fun setupRecyclerView() {
        adapter = DosenAdapter(emptyList(), this)
        binding.rvDosen.layoutManager = LinearLayoutManager(requireContext())
        binding.rvDosen.adapter = adapter
        
        // Add item animation
        binding.rvDosen.layoutAnimation = AnimationUtils.loadLayoutAnimation(
            requireContext(),
            R.anim.layout_animation_slide_up
        )
    }

    private fun validateAndSave() {
        val nidn = binding.etNidn.text.toString().trim()
        val nama = binding.etNamaDosen.text.toString().trim()
        val jabatan = binding.spJabatan.selectedItem.toString()

        // Validation
        if (nidn.isEmpty()) {
            binding.tilNidn.error = "NIDN is required"
            shakeView(binding.tilNidn)
            return
        }

        if (nidn.length > 10) {
            binding.tilNidn.error = "NIDN max 10 characters"
            shakeView(binding.tilNidn)
            return
        }

        if (nama.isEmpty()) {
            binding.tilNama.error = "Name is required"
            shakeView(binding.tilNama)
            return
        }

        // Clear errors
        binding.tilNidn.error = null
        binding.tilNama.error = null

        saveDosen(nidn, nama, jabatan)
    }

    override fun onEdit(dosen: Dosen) {
        showEditDialog(dosen)
    }

    override fun onDelete(dosen: Dosen) {
        showDeleteDialog(dosen)
    }

    private fun showEditDialog(dosen: Dosen) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_edit_dosen, null)
        val etNama = dialogView.findViewById<android.widget.EditText>(R.id.etEditNama)
        val spJabatan = dialogView.findViewById<android.widget.Spinner>(R.id.spEditJabatan)

        etNama.setText(dosen.nama_dosen)

        val jabatans = arrayOf("Lektor", "Asisten Ahli", "Lektor Kepala", "Profesor")
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, jabatans)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spJabatan.adapter = spinnerAdapter
        
        val position = jabatans.indexOf(dosen.jabatan)
        if (position >= 0) {
            spJabatan.setSelection(position)
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("✏️ Edit Dosen")
            .setView(dialogView)
            .setPositiveButton("Update") { _, _ ->
                val newNama = etNama.text.toString()
                val newJabatan = spJabatan.selectedItem.toString()
                updateDosen(dosen.nidn, newNama, newJabatan)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteDialog(dosen: Dosen) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("🗑️ Hapus Dosen")
            .setMessage("Yakin ingin menghapus ${dosen.nama_dosen}?")
            .setPositiveButton("Hapus") { _, _ ->
                deleteDosen(dosen.nidn)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateDosen(nidn: String, nama: String, jabatan: String) {
        RetrofitClient.phpApi.updateDosen(nidn, nama, jabatan).enqueue(object : Callback<DosenResponse> {
            override fun onResponse(call: Call<DosenResponse>, response: Response<DosenResponse>) {
                if (response.isSuccessful && response.body()?.status == "success") {
                    Toast.makeText(requireContext(), "✅ Berhasil Update!", Toast.LENGTH_SHORT).show()
                    fetchDosen()
                } else {
                    Toast.makeText(requireContext(), "❌ Gagal Update: ${response.body()?.message}", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<DosenResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun deleteDosen(nidn: String) {
        RetrofitClient.phpApi.deleteDosen(nidn).enqueue(object : Callback<DosenResponse> {
            override fun onResponse(call: Call<DosenResponse>, response: Response<DosenResponse>) {
                if (response.isSuccessful && response.body()?.status == "success") {
                    Toast.makeText(requireContext(), "✅ Berhasil Hapus!", Toast.LENGTH_SHORT).show()
                    fetchDosen()
                } else {
                    Toast.makeText(requireContext(), "❌ Gagal Hapus: ${response.body()?.message}", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<DosenResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun fetchDosen() {
        RetrofitClient.phpApi.getDosen().enqueue(object : Callback<DosenResponse> {
            override fun onResponse(call: Call<DosenResponse>, response: Response<DosenResponse>) {
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == "success") {
                        val list = body.data ?: emptyList()
                        adapter.updateData(list)
                        dosenCount = list.size
                        
                        // Update count with animation
                        updateDosenCount()
                        
                        binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                        
                        // Animate list
                        binding.rvDosen.scheduleLayoutAnimation()
                    }
                }
            }

            override fun onFailure(call: Call<DosenResponse>, t: Throwable) {
                Log.e("DosenFragment", "Fetch error: ${t.message}")
            }
        })
    }

    private fun updateDosenCount() {
        binding.tvDosenCount.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(100)
            .withEndAction {
                binding.tvDosenCount.text = "$dosenCount Dosen"
                binding.tvDosenCount.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .start()
            }
            .start()
    }

    private fun saveDosen(nidn: String, nama: String, jabatan: String) {
        // Show loading state
        binding.btnSimpanDosen.isEnabled = false
        binding.btnSimpanDosen.text = "Menyimpan..."

        RetrofitClient.phpApi.insertDosen(nidn, nama, jabatan).enqueue(object : Callback<DosenResponse> {
            override fun onResponse(call: Call<DosenResponse>, response: Response<DosenResponse>) {
                binding.btnSimpanDosen.isEnabled = true
                binding.btnSimpanDosen.text = "💾 Simpan Dosen"
                
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == "success") {
                        // Success animation
                        binding.cardForm.animate()
                            .scaleX(1.02f)
                            .scaleY(1.02f)
                            .setDuration(100)
                            .withEndAction {
                                binding.cardForm.animate()
                                    .scaleX(1f)
                                    .scaleY(1f)
                                    .setDuration(100)
                                    .start()
                            }
                            .start()
                            
                        Toast.makeText(requireContext(), "🎉 Berhasil Simpan Dosen!", Toast.LENGTH_SHORT).show()
                        Log.d("DosenFragment", "Saved: $nidn - $nama ($jabatan)")
                        
                        // Clear inputs with animation
                        binding.etNidn.animate().alpha(0f).setDuration(100).withEndAction {
                            binding.etNidn.text?.clear()
                            binding.etNidn.animate().alpha(1f).setDuration(100).start()
                        }.start()
                        
                        binding.etNamaDosen.animate().alpha(0f).setDuration(100).withEndAction {
                            binding.etNamaDosen.text?.clear()
                            binding.etNamaDosen.animate().alpha(1f).setDuration(100).start()
                        }.start()
                        
                        // Refresh list
                        fetchDosen()
                    } else {
                        shakeView(binding.cardForm)
                        Toast.makeText(requireContext(), body?.message ?: "Gagal", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            override fun onFailure(call: Call<DosenResponse>, t: Throwable) {
                binding.btnSimpanDosen.isEnabled = true
                binding.btnSimpanDosen.text = "💾 Simpan Dosen"
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun shakeView(view: View) {
        val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
        view.startAnimation(shake)
    }

    private fun animateButtonPress(view: View) {
        val scaleDown = AnimationUtils.loadAnimation(requireContext(), R.anim.scale_down)
        val scaleUp = AnimationUtils.loadAnimation(requireContext(), R.anim.scale_up)

        view.startAnimation(scaleDown)
        view.postDelayed({
            view.startAnimation(scaleUp)
        }, 100)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
