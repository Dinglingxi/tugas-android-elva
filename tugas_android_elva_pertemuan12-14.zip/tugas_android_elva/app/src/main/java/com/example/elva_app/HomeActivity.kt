package com.example.elva_app

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.elva_app.databinding.ActivityHomeBinding
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private var currentFragmentTag: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 🎨 Setup Toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(true)
        
        // 🚀 Start entrance animations
        startEntranceAnimations()

        // 📱 Set default fragment with animation
        loadFragment(UserFragment(), "users")

        // 🧭 Bottom navigation with animations
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_users -> {
                    if (currentFragmentTag != "users") {
                        loadFragment(UserFragment(), "users")
                    }
                    true
                }
                R.id.nav_dosen -> {
                    if (currentFragmentTag != "dosen") {
                        loadFragment(DosenFragment(), "dosen")
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun startEntranceAnimations() {
        // Animate toolbar
        binding.toolbar.alpha = 0f
        binding.toolbar.translationY = -50f
        binding.toolbar.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .start()

        // Animate bottom navigation
        binding.bottomNavigation.alpha = 0f
        binding.bottomNavigation.translationY = 50f
        binding.bottomNavigation.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .setStartDelay(200)
            .start()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_toolbar, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                performLogout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun performLogout() {
        // Animate out
        binding.fragmentContainer.animate()
            .alpha(0f)
            .setDuration(300)
            .withEndAction {
                FirebaseAuth.getInstance().signOut()
                startActivity(Intent(this, LoginActivity::class.java))
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                finish()
            }
            .start()
    }

    private fun loadFragment(fragment: Fragment, tag: String) {
        currentFragmentTag = tag
        
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                R.anim.fade_in,
                R.anim.fade_out,
                R.anim.fade_in,
                R.anim.fade_out
            )
            .replace(R.id.fragment_container, fragment, tag)
            .commit()
    }
}
