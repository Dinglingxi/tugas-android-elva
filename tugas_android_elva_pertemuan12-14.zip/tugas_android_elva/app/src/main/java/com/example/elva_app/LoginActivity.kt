package com.example.elva_app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.example.elva_app.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        // 🚀 Start entrance animations
        startEntranceAnimations()
        
        // 📱 Setup input listeners
        setupInputListeners()

        // 🔐 Login button
        binding.btnLogin.setOnClickListener {
            animateButtonPress(it)
            performLogin()
        }

        // 📝 Register link
        binding.tvToRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        // 🔑 Forgot password
        binding.tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show()
        }

        // 🔵 Social login buttons
        binding.btnGoogle.setOnClickListener {
            animateButtonPress(it)
            Toast.makeText(this, "Google Sign-In coming soon!", Toast.LENGTH_SHORT).show()
        }

        binding.btnFacebook.setOnClickListener {
            animateButtonPress(it)
            Toast.makeText(this, "Facebook Sign-In coming soon!", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun startEntranceAnimations() {
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        val slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up)
        val bounceIn = AnimationUtils.loadAnimation(this, R.anim.bounce_in)

        // Animate logo
        binding.logoContainer.startAnimation(bounceIn)
        
        // Animate texts with delay
        binding.tvWelcome.alpha = 0f
        binding.tvWelcome.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .setStartDelay(300)
            .start()

        binding.tvSubtitle.alpha = 0f
        binding.tvSubtitle.animate()
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(400)
            .start()

        // Animate card
        binding.cardLogin.alpha = 0f
        binding.cardLogin.translationY = 100f
        binding.cardLogin.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(600)
            .setStartDelay(500)
            .start()

        // Start logo glow animation
        val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
        binding.logoGlow.startAnimation(pulse)
    }

    private fun setupInputListeners() {
        binding.etEmail.doAfterTextChanged { text ->
            // Clear error when typing
            binding.tilEmail.error = null
        }

        binding.etPassword.doAfterTextChanged { text ->
            binding.tilPassword.error = null
        }
    }

    private fun animateButtonPress(view: View) {
        val scaleDown = AnimationUtils.loadAnimation(this, R.anim.scale_down)
        val scaleUp = AnimationUtils.loadAnimation(this, R.anim.scale_up)
        
        view.startAnimation(scaleDown)
        view.postDelayed({
            view.startAnimation(scaleUp)
        }, 100)
    }

    private fun performLogin() {
        val email = binding.etEmail.text.toString().trim()
        val pass = binding.etPassword.text.toString()

        // Validation
        if (email.isEmpty()) {
            binding.tilEmail.error = "Email is required"
            shakeView(binding.tilEmail)
            return
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.error = "Please enter a valid email"
            shakeView(binding.tilEmail)
            return
        }

        if (pass.isEmpty()) {
            binding.tilPassword.error = "Password is required"
            shakeView(binding.tilPassword)
            return
        }

        if (pass.length < 6) {
            binding.tilPassword.error = "Password must be at least 6 characters"
            shakeView(binding.tilPassword)
            return
        }

        // Show loading
        showLoading(true)

        auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener { task ->
            showLoading(false)
            
            if (task.isSuccessful) {
                // Success animation
                binding.cardLogin.animate()
                    .scaleX(0.95f)
                    .scaleY(0.95f)
                    .setDuration(100)
                    .withEndAction {
                        binding.cardLogin.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(100)
                            .withEndAction {
                                startActivity(Intent(this, HomeActivity::class.java))
                                overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                                finish()
                            }
                            .start()
                    }
                    .start()
            } else {
                // Error animation
                shakeView(binding.cardLogin)
                Toast.makeText(this, task.exception?.message ?: "Login failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun shakeView(view: View) {
        val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
        view.startAnimation(shake)
    }

    private fun showLoading(show: Boolean) {
        binding.loadingOverlay.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !show
    }
}
