package com.example.elva_app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.example.elva_app.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        // 🚀 Start entrance animations
        startEntranceAnimations()

        // 🔙 Back button
        binding.btnBack.setOnClickListener {
            onBackPressed()
        }

        // 📝 Password strength checker
        setupPasswordStrength()

        // 📝 Input listeners
        setupInputListeners()

        // 🚀 Register button
        binding.btnRegister.setOnClickListener {
            animateButtonPress(it)
            performRegistration()
        }

        // 🔐 Login link
        binding.tvToLogin.setOnClickListener {
            finish()
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
    }

    private fun startEntranceAnimations() {
        val bounceIn = AnimationUtils.loadAnimation(this, R.anim.bounce_in)

        // Animate logo
        binding.logoContainer.startAnimation(bounceIn)

        // Animate title
        binding.tvTitle.alpha = 0f
        binding.tvTitle.animate()
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(200)
            .start()

        binding.tvSubtitle.alpha = 0f
        binding.tvSubtitle.animate()
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(300)
            .start()

        // Animate card
        binding.cardRegister.alpha = 0f
        binding.cardRegister.translationY = 100f
        binding.cardRegister.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(600)
            .setStartDelay(400)
            .start()
    }

    private fun setupPasswordStrength() {
        binding.etPassword.doAfterTextChanged { text ->
            val password = text.toString()
            
            if (password.isEmpty()) {
                binding.passwordStrengthContainer.visibility = View.GONE
                return@doAfterTextChanged
            }

            binding.passwordStrengthContainer.visibility = View.VISIBLE
            
            val strength = calculatePasswordStrength(password)
            updateStrengthBars(strength)
        }
    }

    private fun calculatePasswordStrength(password: String): Int {
        var strength = 0
        
        if (password.length >= 6) strength++
        if (password.length >= 8) strength++
        if (password.any { it.isUpperCase() }) strength++
        if (password.any { it.isDigit() }) strength++
        if (password.any { !it.isLetterOrDigit() }) strength++
        
        return strength.coerceAtMost(4)
    }

    private fun updateStrengthBars(strength: Int) {
        val weakColor = Color.parseColor("#EF4444")
        val fairColor = Color.parseColor("#F59E0B")
        val goodColor = Color.parseColor("#22D3EE")
        val strongColor = Color.parseColor("#10B981")
        val emptyColor = Color.parseColor("#E5E7EB")

        val bars = listOf(
            binding.strengthBar1,
            binding.strengthBar2,
            binding.strengthBar3,
            binding.strengthBar4
        )

        val colors = when (strength) {
            1 -> listOf(weakColor, emptyColor, emptyColor, emptyColor)
            2 -> listOf(fairColor, fairColor, emptyColor, emptyColor)
            3 -> listOf(goodColor, goodColor, goodColor, emptyColor)
            4 -> listOf(strongColor, strongColor, strongColor, strongColor)
            else -> listOf(emptyColor, emptyColor, emptyColor, emptyColor)
        }

        val strengthText = when (strength) {
            1 -> "Weak"
            2 -> "Fair"
            3 -> "Good"
            4 -> "Strong 💪"
            else -> ""
        }

        bars.forEachIndexed { index, bar ->
            bar.animate()
                .scaleX(if (colors[index] != emptyColor) 1f else 0.8f)
                .setDuration(200)
                .start()
            bar.setBackgroundColor(colors[index])
        }

        binding.tvPasswordStrength.text = strengthText
        binding.tvPasswordStrength.setTextColor(colors[0])
    }

    private fun setupInputListeners() {
        binding.etEmail.doAfterTextChanged {
            binding.tilEmail.error = null
        }

        binding.etConfirmPassword.doAfterTextChanged { text ->
            binding.tilConfirmPassword.error = null
            
            val password = binding.etPassword.text.toString()
            val confirm = text.toString()
            
            if (confirm.isNotEmpty() && password != confirm) {
                binding.tilConfirmPassword.error = "Passwords don't match"
            }
        }
    }

    private fun animateButtonPress(view: View) {
        val scaleDown = AnimationUtils.loadAnimation(this, R.anim.scale_down)
        val scaleUp = AnimationUtils.loadAnimation(this, R.anim.scale_up)

        view.startAnimation(scaleDown)
        view.postDelayed({
            view.startAnimation(scaleUp)
        }, 100)
    }

    private fun performRegistration() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()
        val confirmPassword = binding.etConfirmPassword.text.toString()

        // Validation
        if (email.isEmpty()) {
            binding.tilEmail.error = "Email is required"
            shakeView(binding.tilEmail)
            return
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.error = "Please enter a valid email"
            shakeView(binding.tilEmail)
            return
        }

        if (password.isEmpty()) {
            binding.tilPassword.error = "Password is required"
            shakeView(binding.tilPassword)
            return
        }

        if (password.length < 6) {
            binding.tilPassword.error = "Password must be at least 6 characters"
            shakeView(binding.tilPassword)
            return
        }

        if (confirmPassword.isEmpty()) {
            binding.tilConfirmPassword.error = "Please confirm your password"
            shakeView(binding.tilConfirmPassword)
            return
        }

        if (password != confirmPassword) {
            binding.tilConfirmPassword.error = "Passwords don't match"
            shakeView(binding.tilConfirmPassword)
            return
        }

        if (!binding.cbTerms.isChecked) {
            shakeView(binding.cbTerms)
            Toast.makeText(this, "Please agree to Terms & Conditions", Toast.LENGTH_SHORT).show()
            return
        }

        // Show loading
        showLoading(true)

        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
            showLoading(false)

            if (task.isSuccessful) {
                // Success animation
                binding.cardRegister.animate()
                    .scaleX(1.02f)
                    .scaleY(1.02f)
                    .setDuration(150)
                    .withEndAction {
                        binding.cardRegister.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(150)
                            .start()
                        
                        Toast.makeText(this, "🎉 Registration Successful!", Toast.LENGTH_SHORT).show()
                        
                        startActivity(Intent(this, LoginActivity::class.java))
                        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                        finish()
                    }
                    .start()
            } else {
                shakeView(binding.cardRegister)
                Toast.makeText(this, task.exception?.message ?: "Registration failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun shakeView(view: View) {
        val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
        view.startAnimation(shake)
    }

    private fun showLoading(show: Boolean) {
        binding.loadingOverlay.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !show
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }
}
