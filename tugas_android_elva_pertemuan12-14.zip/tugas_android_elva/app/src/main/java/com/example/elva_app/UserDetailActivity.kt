package com.example.elva_app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.elva_app.databinding.ActivityUserDetailBinding

class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val firstName = intent.getStringExtra("user_first_name")
        val lastName = intent.getStringExtra("user_last_name")
        val email = intent.getStringExtra("user_email")
        val avatar = intent.getStringExtra("user_avatar")

        binding.tvDetailName.text = "$firstName $lastName"
        binding.tvDetailEmail.text = email

        Glide.with(this)
            .load(avatar)
            .into(binding.ivDetailAvatar)
    }
}
