package com.example.elva_app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.elva_app.adapter.UserAdapter
import com.example.elva_app.databinding.FragmentUserBinding
import com.example.elva_app.model.User
import com.example.elva_app.model.UserResponse
import com.example.elva_app.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserFragment : Fragment() {

    private var _binding: FragmentUserBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: UserAdapter
    private var currentPage = 1
    private var totalPages = 1
    private var totalUsers = 0
    private var allUsers = mutableListOf<User>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 🚀 Start entrance animations
        startEntranceAnimations()

        // 📋 Setup RecyclerView
        setupRecyclerView()

        // 🔍 Setup search
        setupSearch()

        // 📊 Fetch initial data
        fetchUsers(currentPage)

        // 📱 Pagination button
        binding.btnNextPage.setOnClickListener {
            animateButtonPress(it)
            
            if (currentPage < totalPages) {
                currentPage++
                fetchUsers(currentPage)
                updatePageIndicator()
            } else {
                Toast.makeText(requireContext(), "🎉 All users loaded!", Toast.LENGTH_SHORT).show()
                binding.btnNextPage.visibility = View.GONE
            }
        }
    }

    private fun startEntranceAnimations() {
        // Animate stats card
        binding.cardStats.alpha = 0f
        binding.cardStats.translationY = -30f
        binding.cardStats.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .start()

        // Animate search bar
        binding.tilSearch.alpha = 0f
        binding.tilSearch.animate()
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(200)
            .start()

        // Animate button
        binding.btnNextPage.alpha = 0f
        binding.btnNextPage.translationY = 30f
        binding.btnNextPage.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .setStartDelay(400)
            .start()
    }

    private fun setupRecyclerView() {
        adapter = UserAdapter(mutableListOf()) { user ->
            // Navigate to DetailActivity with animation
            val intent = Intent(requireContext(), UserDetailActivity::class.java)
            intent.putExtra("user_first_name", user.firstName)
            intent.putExtra("user_last_name", user.lastName)
            intent.putExtra("user_email", user.email)
            intent.putExtra("user_avatar", user.avatar)
            startActivity(intent)
            activity?.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.rvUsers.layoutManager = LinearLayoutManager(requireContext())
        binding.rvUsers.adapter = adapter
        
        // Add item animation
        binding.rvUsers.layoutAnimation = AnimationUtils.loadLayoutAnimation(
            requireContext(),
            R.anim.layout_animation_slide_up
        )
    }

    private fun setupSearch() {
        binding.etSearch.doAfterTextChanged { text ->
            val query = text.toString().lowercase()
            
            if (query.isEmpty()) {
                adapter.clearData()
                adapter.addData(allUsers)
            } else {
                val filtered = allUsers.filter { user ->
                    user.firstName.lowercase().contains(query) ||
                    user.lastName.lowercase().contains(query) ||
                    user.email.lowercase().contains(query)
                }
                adapter.clearData()
                adapter.addData(filtered)
            }
            
            updateEmptyState()
        }
    }

    private fun fetchUsers(page: Int) {
        // Show loading state
        binding.btnNextPage.isEnabled = false
        binding.btnNextPage.text = "Loading..."

        RetrofitClient.reqres.getUsers(page).enqueue(object : Callback<UserResponse> {
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                binding.btnNextPage.isEnabled = true
                binding.btnNextPage.text = "Load More Users"
                
                if (response.isSuccessful) {
                    val body = response.body()
                    body?.let {
                        totalPages = it.totalPages
                        totalUsers = it.total
                        
                        allUsers.addAll(it.data)
                        adapter.addData(it.data)
                        
                        // Update stats with animation
                        updateStats()
                        updateEmptyState()
                        
                        // Animate new items
                        binding.rvUsers.scheduleLayoutAnimation()
                    }
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Failed to load users: ${response.code()} ${response.message()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                binding.btnNextPage.isEnabled = true
                binding.btnNextPage.text = "Retry"
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun updateStats() {
        // Animate count up
        binding.tvTotalUsers.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(100)
            .withEndAction {
                binding.tvTotalUsers.text = totalUsers.toString()
                binding.tvTotalUsers.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .start()
            }
            .start()
    }

    private fun updatePageIndicator() {
        binding.tvCurrentPage.animate()
            .scaleX(1.2f)
            .scaleY(1.2f)
            .setDuration(100)
            .withEndAction {
                binding.tvCurrentPage.text = currentPage.toString()
                binding.tvCurrentPage.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .start()
            }
            .start()
    }

    private fun updateEmptyState() {
        if (adapter.itemCount == 0) {
            binding.emptyState.visibility = View.VISIBLE
            binding.rvUsers.visibility = View.GONE
        } else {
            binding.emptyState.visibility = View.GONE
            binding.rvUsers.visibility = View.VISIBLE
        }
    }

    private fun animateButtonPress(view: View) {
        val scaleDown = AnimationUtils.loadAnimation(requireContext(), R.anim.scale_down)
        val scaleUp = AnimationUtils.loadAnimation(requireContext(), R.anim.scale_up)

        view.startAnimation(scaleDown)
        view.postDelayed({
            view.startAnimation(scaleUp)
        }, 100)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
