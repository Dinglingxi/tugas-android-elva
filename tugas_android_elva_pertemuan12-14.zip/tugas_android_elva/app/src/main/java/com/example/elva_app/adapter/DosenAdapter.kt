package com.example.elva_app.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.elva_app.R
import com.example.elva_app.databinding.ItemDosenBinding
import com.example.elva_app.model.Dosen

class DosenAdapter(
    private var dosenList: List<Dosen>,
    private val listener: OnDosenActionListener
) : RecyclerView.Adapter<DosenAdapter.DosenViewHolder>() {

    private var lastAnimatedPosition = -1

    interface OnDosenActionListener {
        fun onEdit(dosen: Dosen)
        fun onDelete(dosen: Dosen)
    }

    inner class DosenViewHolder(val binding: ItemDosenBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DosenViewHolder {
        val binding = ItemDosenBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DosenViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DosenViewHolder, position: Int) {
        val dosen = dosenList[position]
        
        // 👤 Bind data
        holder.binding.itemNamaDosen.text = dosen.nama_dosen
        holder.binding.itemNidn.text = "NIDN: ${dosen.nidn}"
        holder.binding.itemJabatan.text = dosen.jabatan

        // 🏷️ Set jabatan badge color based on position
        val badgeColor = when (dosen.jabatan) {
            "Profesor" -> Color.parseColor("#7C3AED")
            "Lektor Kepala" -> Color.parseColor("#2563EB")
            "Lektor" -> Color.parseColor("#059669")
            "Asisten Ahli" -> Color.parseColor("#F59E0B")
            else -> Color.parseColor("#10B981")
        }
        holder.binding.itemJabatan.background.setTint(badgeColor)

        // 🔧 Edit button with animation
        holder.binding.btnEdit.setOnClickListener {
            animateButton(holder.binding.btnEdit) {
                listener.onEdit(dosen)
            }
        }

        // 🗑️ Delete button with animation
        holder.binding.btnDelete.setOnClickListener {
            animateButton(holder.binding.btnDelete) {
                listener.onDelete(dosen)
            }
        }

        // 🎭 Animate item appearance (only once)
        if (position > lastAnimatedPosition) {
            val animation = AnimationUtils.loadAnimation(holder.itemView.context, R.anim.item_slide_up)
            animation.startOffset = (position * 50).toLong()
            holder.itemView.startAnimation(animation)
            lastAnimatedPosition = position
        }
    }

    private fun animateButton(view: android.view.View, action: () -> Unit) {
        view.animate()
            .scaleX(0.9f)
            .scaleY(0.9f)
            .setDuration(100)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .withEndAction {
                        action()
                    }
                    .start()
            }
            .start()
    }

    override fun getItemCount(): Int = dosenList.size

    fun updateData(newDosenList: List<Dosen>) {
        lastAnimatedPosition = -1
        dosenList = newDosenList
        notifyDataSetChanged()
    }
}
