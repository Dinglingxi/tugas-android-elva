package com.example.elva_app.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.example.elva_app.R
import com.example.elva_app.databinding.ItemUserBinding
import com.example.elva_app.model.User

class UserAdapter(
    private var users: MutableList<User>,
    private val onClick: (User) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    private var lastAnimatedPosition = -1

    inner class UserViewHolder(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = users[position]
        
        // 👤 Bind data
        holder.binding.tvName.text = "${user.firstName} ${user.lastName}"
        holder.binding.tvEmail.text = user.email
        
        // 🖼️ Load avatar with Glide
        Glide.with(holder.itemView.context)
            .load(user.avatar)
            .transform(CircleCrop())
            .placeholder(R.drawable.ic_person)
            .into(holder.binding.ivAvatar)

        // 🔘 Click listener with animation
        holder.itemView.setOnClickListener { 
            // Animate press
            holder.itemView.animate()
                .scaleX(0.95f)
                .scaleY(0.95f)
                .setDuration(100)
                .withEndAction {
                    holder.itemView.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .start()
                    onClick(user)
                }
                .start()
        }

        // 🎭 Animate item appearance (only once)
        if (position > lastAnimatedPosition) {
            val animation = AnimationUtils.loadAnimation(holder.itemView.context, R.anim.item_slide_up)
            animation.startOffset = (position * 50).toLong()
            holder.itemView.startAnimation(animation)
            lastAnimatedPosition = position
        }
    }

    override fun getItemCount(): Int = users.size

    fun addData(newData: List<User>) {
        val startPos = users.size
        users.addAll(newData)
        notifyItemRangeInserted(startPos, newData.size)
    }

    fun clearData() {
        lastAnimatedPosition = -1
        users.clear()
        notifyDataSetChanged()
    }
}
