package com.example.elva_app.model

data class Dosen(
    val nidn: String,
    val nama_dosen: String,
    val jabatan: String
)

data class DosenResponse(
    val status: String,
    val message: String,
    val data: List<Dosen>? = null
)
