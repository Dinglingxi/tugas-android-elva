package com.example.elva_app.network

import com.example.elva_app.model.DosenResponse
import com.example.elva_app.model.UserResponse
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface ApiService {
    @GET("read_users.php")
    fun getUsers(@Query("page") page: Int): Call<UserResponse>

    @GET("read_dosen.php")
    fun getDosen(): Call<DosenResponse>

    @FormUrlEncoded
    @POST("create_dosen.php")
    fun insertDosen(
        @Field("nidn") nidn: String,
        @Field("nama_dosen") nama_dosen: String,
        @Field("jabatan") jabatan: String
    ): Call<DosenResponse>

    @FormUrlEncoded
    @POST("update_dosen.php")
    fun updateDosen(
        @Field("nidn") nidn: String,
        @Field("nama_dosen") nama_dosen: String,
        @Field("jabatan") jabatan: String
    ): Call<DosenResponse>

    @FormUrlEncoded
    @POST("delete_dosen.php")
    fun deleteDosen(
        @Field("nidn") nidn: String
    ): Call<DosenResponse>
}

object RetrofitClient {
    private const val REQRES_URL = "https://reqres.in/"
    
    private const val PHP_API_URL = "http://10.153.129.214/db_kampus_api/" 

    private fun getClient(baseUrl: String): ApiService {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    val reqres: ApiService by lazy { getClient(PHP_API_URL) }
    val phpApi: ApiService by lazy { getClient(PHP_API_URL) }
}
