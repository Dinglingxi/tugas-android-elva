<?php
include 'config.php';

$nidn   = $_POST['nidn'];
$nama   = $_POST['nama_dosen'];
$jabatan = $_POST['jabatan'];

if (!empty($nidn) && !empty($nama)) {
    $query = "INSERT INTO tb_dosen (nidn, nama_dosen, jabatan) VALUES ('$nidn', '$nama', '$jabatan')";
    if (mysqli_query($conn, $query)) {
        echo json_encode(array("status" => "success", "message" => "Berhasil Simpan Dosen"));
    } else {
        echo json_encode(array("status" => "error", "message" => mysqli_error($conn)));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Semua field harus diisi"));
}
?>
