<?php
include 'config.php';

$nidn = $_POST['nidn'];

if (!empty($nidn)) {
    $query = "DELETE FROM tb_dosen WHERE nidn = '$nidn'";
    
    if (mysqli_query($conn, $query)) {
        echo json_encode(array("status" => "success", "message" => "Berhasil Hapus Dosen"));
    } else {
        echo json_encode(array("status" => "error", "message" => mysqli_error($conn)));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "NIDN diperlukan"));
}
?>
