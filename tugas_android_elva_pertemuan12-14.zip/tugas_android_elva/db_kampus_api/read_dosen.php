<?php
include 'config.php';

$query = "SELECT * FROM tb_dosen";
$result = mysqli_query($conn, $query);

$output = array();
while ($row = mysqli_fetch_assoc($result)) {
    $output[] = $row;
}

echo json_encode(array(
    "status" => "success",
    "message" => "Data Dosen",
    "data" => $output
));
?>
