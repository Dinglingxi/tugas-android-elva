<?php
header("Content-Type: application/json");

// Simulasi data seperti ReqRes
$data = [
    [
        "id" => 1,
        "email" => "george.bluth@reqres.in",
        "first_name" => "George",
        "last_name" => "Bluth",
        "avatar" => "http://10.153.129.214/db_kampus_api/faces/1.jpg"
    ],
    [
        "id" => 2,
        "email" => "janet.weaver@reqres.in",
        "first_name" => "Janet",
        "last_name" => "Weaver",
        "avatar" => "http://10.153.129.214/db_kampus_api/faces/2.jpg"
    ],
    [
        "id" => 3,
        "email" => "emma.wong@reqres.in",
        "first_name" => "Emma",
        "last_name" => "Wong",
        "avatar" => "http://10.153.129.214/db_kampus_api/faces/3.jpg"
    ],
    [
        "id" => 4,
        "email" => "eve.holt@reqres.in",
        "first_name" => "Eve",
        "last_name" => "Holt",
        "avatar" => "http://10.153.129.214/db_kampus_api/faces/4.jpg"
    ],
    [
        "id" => 5,
        "email" => "charles.morris@reqres.in",
        "first_name" => "Charles",
        "last_name" => "Morris",
        "avatar" => "http://10.153.129.214/db_kampus_api/faces/5.jpg"
    ],
    [
        "id" => 6,
        "email" => "tracey.ramos@reqres.in",
        "first_name" => "Tracey",
        "last_name" => "Ramos",
        "avatar" => "http://10.153.129.214/db_kampus_api/faces/6.jpg"
    ]
];

// Output JSON dengan format { "data": [...] } sesuai UserResponse.kt
echo json_encode([
    "page" => 1,
    "per_page" => 6,
    "total" => 12,
    "total_pages" => 2,
    "data" => $data
]);
?>
