<?php
include 'config.php';

$nidn = $_POST['nidn'];
$nama = $_POST['nama_dosen'];
$jabatan = $_POST['jabatan'];

if (!empty($nidn) && !empty($nama) && !empty($jabatan)) {
    $query = "UPDATE tb_dosen SET nama_dosen = '$nama', jabatan = '$jabatan' WHERE nidn = '$nidn'";
    
    if (mysqli_query($conn, $query)) {
        echo json_encode(array("status" => "success", "message" => "Berhasil Update Dosen"));
    } else {
        echo json_encode(array("status" => "error", "message" => mysqli_error($conn)));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Data tidak lengkap"));
}
?>
